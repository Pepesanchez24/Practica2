package dao;

/**
 * Factory concreta para crear instancias de DAO que usan JPA.
 * Implementa el patrón Factory Method.
 */
public class JPADAOFactory extends DAOFactory {

    @Override
    public AcademiaDAO crearAcademiaDAO() {
        return new AcademiaDAOImplJPA();
    }
}