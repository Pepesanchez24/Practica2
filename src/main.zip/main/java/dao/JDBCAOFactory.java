package dao;

/**
 * Factory concreta para crear instancias de DAO que usan JDBC.
 * Implementa el patrón Factory Method.
 */
public class JDBCAOFactory extends DAOFactory {

    @Override
    public AcademiaDAO crearAcademiaDAO() {
        return new AcademiaDAOImplJDBC();
    }
}